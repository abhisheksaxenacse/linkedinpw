const { test,expect } = require('@playwright/test');
const {ViewSettingInNewTabPage} = require('../pageobject/ViewSettingInNewTabPage');
const {LoginPage} = require('../pageobject/LoginPage');
const {TestData} = require('../fixtures/testdata');
//const {LinkedinHelper} = require('../helper/linkedinhelper');

let testdata, linkedinhelper, viewsettinginnewtabpage, loginpage;

// test.beforeEach(async ({ page }) => {
//     await page.goto('/home');
//     viewsettinginnewtabpage = new ViewSettingInNewTabPage (page);
//     testdata = new TestData(page);  
//     linkedinhelper = new LinkedinHelper(page)
//   });

  test.afterEach(async ({ page }) => {
    // await page.screenshot({ path: Date.now() + 'screenshot.png'});
    page.close()
  });

  //to run test in file in parallel
  test.describe.configure({mode:"parallel"})
  
  test('Opening setting in new tab and various assertions', async ({ browser }) => {

    const context = await browser.newContext();
    const page = await context.newPage();
    loginpage = new LoginPage(page);
    testdata = new TestData(page);  
    viewsettinginnewtabpage = new ViewSettingInNewTabPage (page)
    page.goto("https://www.linkedin.com/home/");
    await loginpage.clickOnSignInButtonOnMainPage ()
    await loginpage.enterEmailOnLoginPage(testdata.EmailMobile)
    await loginpage.enterPasswordOnLoginPage(testdata.Password)
    await loginpage.clickOnSignInButtonOnLoginPage ()
    await page.waitForLoadState("load")
    //Verification step to check URL after successful login
    await loginpage.verifyHomeFeedUrl(page,testdata.HomeFeedURL)
    await viewsettinginnewtabpage.clickOnNotificationIcon ()
    const [newPage1] = await Promise.all([
       context.waitForEvent('page'),
       viewsettinginnewtabpage.clickViewSettingLink (),
     ])
 
    await expect(newPage1.locator("//div[@class='sans-title-medium']")).toHaveText("Settings") ;
    
  });


