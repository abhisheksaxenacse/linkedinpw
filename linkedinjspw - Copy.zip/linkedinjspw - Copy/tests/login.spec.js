const { test } = require('@playwright/test');
const {LoginPage} = require('../pageobject/LoginPage');
const {TestData} = require('../fixtures/testdata');
const {LinkedinHelper} = require('../helper/linkedinhelper');

let loginpage, testdata, linkedinhelper;

test.beforeEach(async ({ page }) => {
    await page.goto('/home');
    loginpage = new LoginPage (page);
    testdata = new TestData(page);  
    linkedinhelper = new LinkedinHelper(page)
  });

  test.afterEach(async ({ page }) => {
    // await page.screenshot({ path: Date.now() + 'screenshot.png'});
    page.close()
  });

  //to run test in file in parallel
  test.describe.configure({mode:"parallel"})
  
  test('successful login with correct credentials and logout', async ({ page }) => {
    await loginpage.clickOnSignInButtonOnMainPage ()
    await loginpage.enterEmailOnLoginPage(testdata.EmailMobile)
    await loginpage.enterPasswordOnLoginPage(testdata.Password)
    await loginpage.clickOnSignInButtonOnLoginPage ()
    //await page.screenshot({path: 'D:/development/linkedinjspw/screenshot/'+'test_run_on'+Date.now()+'/'+ Date.now()+'screenshot.png', fullPage : true})
    await page.waitForLoadState("load")
    //Verification step to check URL after successful login
    await loginpage.verifyHomeFeedUrl(page,testdata.HomeFeedURL)
    await loginpage.clickOnSignOut()
    await loginpage.verifSignOutPageText()
    /*Below steps are login and signout methods. These can be used when we want to skip all above step and just
    want to perform login and signout as main test is something else
    */
    /*
    await linkedinhelper.loginMethod(page)
    await linkedinhelper.signOutMethod(page)
    */
  });

  test('fail login with incorrect credentials and taking screenshot', async ({ page }) => {
    await loginpage.clickOnSignInButtonOnMainPage ()
    await loginpage.enterEmailOnLoginPage(testdata.EmailMobile)
    await loginpage.enterPasswordOnLoginPage(testdata.WrongPassword)
    await loginpage.clickOnSignInButtonOnLoginPage ()
    //await page.screenshot({path: 'D:/development/linkedinjspw/screenshot/'+'test_run_on'+Date.now()+'/'+ Date.now()+'screenshot.png', fullPage : true})
    await page.waitForLoadState("load")
    //Verification step to check URL after successful login
    await loginpage.verifyHomeFeedUrl(page,testdata.HomeFeedURL)
    
  });


