const { test } = require('@playwright/test');
const {ProfilePage} = require('../pageobject/ProfilePage');
const {TestData} = require('../fixtures/testdata');
const {LinkedinHelper} = require('../helper/linkedinhelper');

let profilepage, testdata, linkedinhelper;

test.beforeEach(async ({ page }) => {
    await page.goto('/home');
    profilepage = new ProfilePage(page);
    testdata = new TestData(page);  
    linkedinhelper = new LinkedinHelper(page)
  });

  test.afterEach(async ({ page }) => {
    // await page.screenshot({ path: Date.now() + 'screenshot.png'});
    page.close()
  });
  
  test.skip('upload a profile image and delete', async ({ page }) => {
    /*Below steps are login and signout methods.*/
    
    await linkedinhelper.loginMethod(page)
    await profilepage.clickOnProfileImageIcon()
    await profilepage.clickOnEditProfilePicIcon()
    //page.waitForLoadState("load")
    const [filechooser] = await Promise.all([
        // It is important to call waitForEvent before click to set up waiting.
        page.waitForEvent('filechooser'),
        // Opens the file chooser.
        await profilepage.clickOnUploadPicture()
      ]);
    await filechooser.setFiles('D:/development/linkedinjspw/fixtures/sampleimage.jpeg');
    await profilepage.clickOnSavePhoto()
    await profilepage.clickOnHomeIcom()
    await profilepage.clickOnProfileImageIcon()
    await profilepage.verifySuccessfulImageUpload()
    await profilepage.clickOnEditProfilePicIconAfterUpload()
    await profilepage.deleteProfileImage()
    await profilepage.verifySuccessfulImageDelete()
    await linkedinhelper.signOutMethod(page)
    
  });


