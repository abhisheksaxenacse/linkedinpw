const {LoginPage} = require('../pageobject/LoginPage');
const {TestData} = require('../fixtures/testdata');

let loginpage, testdata;

class LinkedinHelper {

    constructor(page){
        loginpage = new LoginPage (page);
        testdata = new TestData(page); 
       
    }
    
    
    async loginMethod(page){
    
        await loginpage.clickOnSignInButtonOnMainPage ()
        await loginpage.enterEmailOnLoginPage(testdata.EmailMobile)
        await loginpage.enterPasswordOnLoginPage(testdata.Password)
        await loginpage.clickOnSignInButtonOnLoginPage ()
        await page.waitForLoadState("load");
    
    }

    async signOutMethod(){
    
        await loginpage.clickOnSignOut()
        await loginpage.verifSignOutPageText()
         
    }
    
    
    
    }
    
    module.exports ={LinkedinHelper};