const { expect, Page } = require('@playwright/test');

class Helper {

    async click(element) {
        await element.click();
    }

    async InputValue(element, value) {
        await element.fill(value);
    }

    async appendText(element, value) {
        await element.type(value);
    }

    async assertElementText(element, value) {
        await expect(element).toHaveText(value);
    }

    async assertElementVisible(element) {
        await element.isVisible;
    }

    async assertElementIsHidden(element) {
        await element.isHidden();
    }

    async assertElementCount(element, count) {
        await expect(element).toHaveCount(count);
    }

    async assertElementTextNotExist(element, value) {
        await expect(element).not.toHaveText(value);
    }

    async assertUrl(page, value) {
        await expect(page).toHaveURL(value);
    }

    
}

module.exports = {Helper}