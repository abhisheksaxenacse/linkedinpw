class TestData {
    EmailMobile="gulivertale@gmail.com";
    Password="goldeneaglE1#";
    WrongPassword="goldeneaglE2#";
    ErrorForPasswordMessage="That's not the right password. Try again or sign in with a one-time link"
    HomeFeedURL="feed/?trk=guest_homepage-basic_nav-header-signin"
    SignOutPageText="Join now"
    TypeInSearchBox="test automation"
    Location="India"
}

module.exports ={TestData};