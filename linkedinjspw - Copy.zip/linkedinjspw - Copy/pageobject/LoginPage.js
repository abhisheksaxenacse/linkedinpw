import { expect } from "@playwright/test";
import { Locator, Page } from "playwright-core";
const {Helper} = require('../helper/helper');


let helper;

class LoginPage {

constructor(page){
    helper = new Helper(); 
    this.signInButtonMainPage = page.locator("//nav[@aria-label='Primary']/div/a[2]");
    this.emailTextBox = page.locator("//input[@id='username']");
    this.passwordTextBox = page.locator("//input[@id='password']");
    this.signInButtonOnLoginPage = page.locator("//button[@aria-label='Sign in']");
    //this.signOutDropDown = page.locator("//div[@id='ember17']//span");
    this.signOutDropDown = page.locator("//button[@aria-expanded='false']/img");
    //this.signOutButton = page.locator("//a[@class='global-nav__secondary-link mv1']");
    //this.signOutButton = page.locator("//nav/ul/li/div/div[@aria-hidden='true']");
    this.signOutButton = page.locator('.global-nav__secondary-link.mv1')
    this.signOutButtonFinal = page.locator("//a[@class='global-nav__secondary-link mv1']");
    this.signOutverifyText = ("//a[@class='nav__button-tertiary btn-md btn-tertiary']");
}

async clickOnSignInButtonOnMainPage () {
    
    await helper.click(this.signInButtonMainPage);
            
}

async enterEmailOnLoginPage (value) {
    await helper.InputValue(this.emailTextBox,value);
    }
    
async enterPasswordOnLoginPage (value) {
    await helper.appendText(this.passwordTextBox,value);
    }

async clickOnSignInButtonOnLoginPage () {
    
    await helper.click(this.signInButtonOnLoginPage);
                
    }

async verifyHomeFeedUrl (page,value) {
        await helper.assertUrl (page,value);
    }

async clickOnSignOut() {
    await helper.click(this.signOutDropDown);
    await helper.click(this.signOutButton);
    await helper.click(this.signOutButtonFinal);
    }

async verifSignOutPageText() {
        await helper.assertElementVisible (this.signOutverifyText);
    }


}

module.exports ={LoginPage};