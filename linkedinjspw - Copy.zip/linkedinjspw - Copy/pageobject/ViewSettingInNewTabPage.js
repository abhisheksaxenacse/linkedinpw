import { expect } from "@playwright/test";
import { Locator, Page } from "playwright-core";
const {Helper} = require('../helper/helper');


let helper;

class ViewSettingInNewTabPage {

constructor(page){
    helper = new Helper(); 
    this.notificationIcon = page.locator("//li-icon[@type='nav-small-notifications-icon']")
    this.viewSettingsLink = page.locator("//div/a[@rel='noopener noreferrer']")

}

async clickOnNotificationIcon () {
    
    await helper.click(this.notificationIcon);
            
}

async clickViewSettingLink () {
    
    await helper.click(this.viewSettingsLink);
            
}





}

module.exports ={ViewSettingInNewTabPage};