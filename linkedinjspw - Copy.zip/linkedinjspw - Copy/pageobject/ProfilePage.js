import { expect } from "@playwright/test";
import { Locator, Page } from "playwright-core";
const {Helper} = require('../helper/helper');


let helper;

class ProfilePage {

constructor(page){
    helper = new Helper(); 
    this.profileImageIcon = page.locator('//div[@class="feed-identity-module artdeco-card overflow-hidden mb2"]/div/a/div/img');
    this.editProfilePicIcon = page.locator("//button[@aria-label='Edit photo']");
    this.editProfilePicIconAfterUpload = page.locator("//button[@class='profile-photo-edit__edit-btn']");
    this.uploadPicture = page.locator("//label[@class='image-selector__file-upload-label artdeco-button ml1 mv0']");
    this.savePhoto = page.locator('//button[@data-control-name="profile_photo_crop_save"]/span[@class="artdeco-button__text"]');
    this.homeIcon = page.locator("//li-icon[@type='nav-small-home-icon']//*[name()='svg']")
    this.imageLocator = page.locator("//div[@class='ph5 ']/div[@class='display-flex']/div[1]/div/div")
    this.trashIcon = page.locator("//li-icon[@type='trash']")
    this.confirmDelete = page.locator("//div/div/div/div/button[2]/span[@class='artdeco-button__text']")
}

async clickOnProfileImageIcon() {
    
    await helper.click(this.profileImageIcon);
            
}

async clickOnEditProfilePicIcon() {
    
    await helper.click(this.editProfilePicIcon);
                
}

async clickOnUploadPicture() {
    
    await helper.click(this.uploadPicture);
                
}

async clickOnSavePhoto() {
    
    await helper.click(this.savePhoto);
                
}

async clickOnHomeIcom() {
    await helper.click(this.homeIcon)
}

async verifySuccessfulImageUpload() {
    await expect(this.imageLocator).toHaveAttribute('class', 'profile-photo-edit pv-top-card__edit-photo');
}

async clickOnEditProfilePicIconAfterUpload() {
    
    await helper.click(this.editProfilePicIconAfterUpload);
                
}

async deleteProfileImage() {
    await helper.click(this.trashIcon)
    await helper.click(this.confirmDelete)
}

async verifySuccessfulImageDelete() {
    await expect(this.imageLocator).toHaveAttribute('class', 'pv-top-card__edit-photo profile-photo-edit');
}

async enterEmailOnLoginPage (value) {
    await helper.InputValue(this.emailTextBox,value);
    }
    
async enterPasswordOnLoginPage (value) {
    await helper.appendText(this.passwordTextBox,value);
    }

async clickOnSignInButtonOnLoginPage () {
    
    await helper.click(this.signInButtonOnLoginPage);
                
    }

async verifyHomeFeedUrl (page,value) {
        await helper.assertUrl (page,value);
    }

async clickOnSignOut() {
    await helper.click(this.signOutDropDown);
    await helper.click(this.signOutButton);
    await helper.click(this.signOutButtonFinal);
    }

async verifSignOutPageText() {
        await helper.assertElementVisible (this.signOutverifyText);
    }


}

module.exports ={ProfilePage};